# Interfaces module - storage adapters
