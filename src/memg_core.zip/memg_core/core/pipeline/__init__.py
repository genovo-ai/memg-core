# Pipeline module - indexing and retrieval
