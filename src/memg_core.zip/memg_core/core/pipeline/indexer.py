"""Indexer: deterministic add-memory pipeline - single writer"""

from __future__ import annotations

from datetime import UTC, datetime
import os

from ..interfaces.embedder import GenAIEmbedder
from ..interfaces.kuzu import KuzuInterface
from ..interfaces.qdrant import QdrantInterface
from ..models import Memory
from ..indexing import build_index_text
from ..exceptions import ProcessingError


def add_memory_index(
    memory: Memory,
    qdrant: QdrantInterface,
    kuzu: KuzuInterface,
    embedder: GenAIEmbedder,
    collection: str | None = None,
) -> str:
    """Add memory to both Qdrant and Kuzu stores - single writer pattern
    
    Args:
        memory: The memory to index
        qdrant: Qdrant interface instance
        kuzu: Kuzu interface instance
        embedder: Embedder interface instance
        collection: Optional Qdrant collection name
        
    Returns:
        The point ID of the indexed memory
        
    Raises:
        ProcessingError: If indexing fails
    """
    try:
        # Build index text based on memory type
        # Check if YAML plugin should be used
        yaml_anchor_text = None
        if os.getenv("MEMG_ENABLE_YAML_SCHEMA", "false").lower() == "true":
            try:
                from ...plugins.yaml_schema import build_index_text_with_yaml
                yaml_anchor_text = build_index_text_with_yaml(memory)
            except Exception:
                # If YAML loading fails, continue with default
                pass
                
        index_text = build_index_text(memory, yaml_anchor_text)
        
        # Generate embedding
        vector = embedder.get_embedding(index_text)
        
        # Prepare Qdrant payload
        payload = memory.to_qdrant_payload()
        payload["index_text"] = index_text
        payload.setdefault("created_at", datetime.now(UTC).isoformat())
        
        # Write to Qdrant
        success, point_id = qdrant.add_point(
            vector=vector,
            payload=payload,
            point_id=memory.id,
            collection=collection,
        )
        
        if not success:
            raise ProcessingError(
                "Failed to upsert memory into Qdrant",
                operation="add_memory_index",
                context={"memory_id": memory.id}
            )
        
        # Write to Kuzu
        kuzu.add_node("Memory", memory.to_kuzu_node())
        
        return point_id
        
    except Exception as e:
        if isinstance(e, ProcessingError):
            raise
        raise ProcessingError(
            "Failed to index memory",
            operation="add_memory_index",
            context={"memory_id": memory.id, "memory_type": memory.memory_type.value},
            original_error=e
        )
