# Core module - minimal exports
