# Plugins module - optional extensions
