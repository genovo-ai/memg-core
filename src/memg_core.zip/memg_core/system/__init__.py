# System module - utilities
