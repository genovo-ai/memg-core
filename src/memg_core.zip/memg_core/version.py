"""Version metadata for memg-core"""

__version__ = "0.1.0"
__author__ = "MEMG Team"
__description__ = "True memory for AI - minimal core"
