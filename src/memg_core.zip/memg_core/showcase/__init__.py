# Showcase module - examples and helpers
