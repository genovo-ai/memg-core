"""Minimal public API for memory system - 4 sync functions only"""

from __future__ import annotations

from datetime import datetime
from typing import Any
import os

from ..core.models import Memory, MemoryType, SearchResult
from ..core.config import get_config
from ..core.interfaces.qdrant import QdrantInterface
from ..core.interfaces.kuzu import KuzuInterface  
from ..core.interfaces.embedder import GenAIEmbedder
from ..core.pipeline.indexer import add_memory_index
from ..core.pipeline.retrieval import graph_rag_search
from ..core.exceptions import ValidationError


def add_note(
    text: str,
    user_id: str,
    title: str | None = None,
    tags: list[str] | None = None,
) -> Memory:
    """Add a note-type memory.

    Args:
        text: The note content
        user_id: User identifier for isolation
        title: Optional title
        tags: Optional list of tags

    Returns:
        The created Memory object
    """
    if not text or not text.strip():
        raise ValidationError("Note content cannot be empty")
    if not user_id:
        raise ValidationError("User ID is required")
        
    memory = Memory(
        user_id=user_id,
        content=text.strip(),
        memory_type=MemoryType.NOTE,
        title=title,
        tags=tags or [],
    )

    # Initialize interfaces
    config = get_config()
    qdrant = QdrantInterface(collection_name=config.memg.qdrant_collection_name)
    kuzu = KuzuInterface(db_path=config.memg.kuzu_database_path)
    embedder = GenAIEmbedder()

    # Index the memory
    memory_id = add_memory_index(memory, qdrant, kuzu, embedder)
    memory.id = memory_id
    
    return memory


def add_document(
    text: str,
    user_id: str,
    title: str | None = None,
    summary: str | None = None,
    tags: list[str] | None = None,
) -> Memory:
    """Add a document-type memory.

    Args:
        text: The document content
        user_id: User identifier for isolation
        title: Optional title
        summary: Optional AI-generated summary (affects indexing)
        tags: Optional list of tags

    Returns:
        The created Memory object
    """
    if not text or not text.strip():
        raise ValidationError("Document content cannot be empty")
    if not user_id:
        raise ValidationError("User ID is required")
        
    memory = Memory(
        user_id=user_id,
        content=text.strip(),
        memory_type=MemoryType.DOCUMENT,
        title=title,
        summary=summary,
        tags=tags or [],
    )

    # Initialize interfaces
    config = get_config()
    qdrant = QdrantInterface(collection_name=config.memg.qdrant_collection_name)
    kuzu = KuzuInterface(db_path=config.memg.kuzu_database_path)
    embedder = GenAIEmbedder()

    # Index the memory
    memory_id = add_memory_index(memory, qdrant, kuzu, embedder)
    memory.id = memory_id
    
    return memory


def add_task(
    text: str,
    user_id: str,
    title: str | None = None,
    due_date: datetime | None = None,
    tags: list[str] | None = None,
) -> Memory:
    """Add a task-type memory.

    Args:
        text: The task description
        user_id: User identifier for isolation
        title: Optional title (affects indexing when combined with content)
        due_date: Optional due date
        tags: Optional list of tags

    Returns:
        The created Memory object
    """
    if not text or not text.strip():
        raise ValidationError("Task content cannot be empty")
    if not user_id:
        raise ValidationError("User ID is required")
        
    memory = Memory(
        user_id=user_id,
        content=text.strip(),
        memory_type=MemoryType.TASK,
        title=title,
        due_date=due_date,
        tags=tags or [],
    )

    # Initialize interfaces
    config = get_config()
    qdrant = QdrantInterface(collection_name=config.memg.qdrant_collection_name)
    kuzu = KuzuInterface(db_path=config.memg.kuzu_database_path)
    embedder = GenAIEmbedder()

    # Index the memory
    memory_id = add_memory_index(memory, qdrant, kuzu, embedder)
    memory.id = memory_id
    
    return memory


def search(
    query: str,
    user_id: str,
    limit: int = 20,
    filters: dict[str, Any] | None = None,
) -> list[SearchResult]:
    """Search memories using GraphRAG (graph-first with vector fallback).

    Args:
        query: Search query string
        user_id: User ID for filtering (required)
        limit: Maximum number of results
        filters: Optional additional filters for vector search

    Returns:
        List of SearchResult objects, ranked by relevance
    """
    if not query or not query.strip():
        raise ValidationError("Search query cannot be empty")
    if not user_id:
        raise ValidationError("User ID is required for search")

    # Initialize interfaces
    config = get_config()
    qdrant = QdrantInterface(collection_name=config.memg.qdrant_collection_name)
    kuzu = KuzuInterface(db_path=config.memg.kuzu_database_path)
    embedder = GenAIEmbedder()

    # Check if YAML schema is enabled to pass relation names
    relation_names = None
    if os.getenv("MEMG_ENABLE_YAML_SCHEMA", "false").lower() == "true":
        # Import only if needed to avoid circular dependency
        from ..plugins.yaml_schema import get_relation_names
        try:
            relation_names = get_relation_names()
        except Exception:
            # If YAML loading fails, use default
            relation_names = None

    # Perform search
    return graph_rag_search(
        query=query.strip(),
        user_id=user_id,
        limit=limit,
        qdrant=qdrant,
        kuzu=kuzu,
        embedder=embedder,
        filters=filters,
        relation_names=relation_names,
    )
