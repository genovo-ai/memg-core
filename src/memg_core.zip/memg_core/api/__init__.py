# API module - public functions
